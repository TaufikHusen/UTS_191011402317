package com.example.sandra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
